#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main() { 
    int readCount = getreadcount();
    printf("Read Count: %d \n", readCount);

 
    exit(0);
}