#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int busyWork()
{
  double	iterCnt = 100000000.0;		// Number of iterations
  double	i = 0.0;			// loop control variable
  double	s = 1.0;			// signal for the next iteration
  double	pi = 0.0;
  
  // pi estimatation via Leibniz's series
  for(i = 1.0; i <= (iterCnt * 2.0); i += 2.0) {
    pi = pi + s * (4.0 / i);
    s = -s;
  }
  return 0;
}

int
main(void)
{

  int numProcesses = 10;
  int ticketAssign[] = {10, 15, 20, 25, 30, 35, 40, 45, 50, 80};
  
  for(int i=0 ; i < numProcesses ; i++) {
      int pid = fork();
      if(pid<0) {exit(1);}
      else if(pid == 0) {   
          settickets(ticketAssign[i]);
          
          acquire(&print_lock);
          printf("Process %d started (ticket count %d)\n", i, gettickets());
          release(&print_lock);

          busyWork();

          acquire(&print_lock);
          printf("Process %d finished\n", i);
          release(&print_lock);
          
          exit(0);
      } 
  }
  
  int addr;
  for(int i = 0 ; i < numProcesses ; i++) {
      wait(&addr);
  }
  
  printf("\n");
  exit(0);
}
