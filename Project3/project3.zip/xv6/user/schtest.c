#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int busyWork() //taken from cpu intensive lab, added more to the iterations
{
  double	iterCnt = 100000000.0;		// Number of iterations
  double	i = 0.0;			// loop control variable
  double	s = 1.0;			// signal for the next iteration
  double	pi = 0.0;
  
  // pi estimatation via Leibniz's series
  for(i = 1.0; i <= (iterCnt * 2.0); i += 2.0) {
    pi = pi + s * (4.0 / i);
    s = -s;
  }
  return 0;
}

int
main(void)
{
  int numProcesses = 10; // set the # of processes
  int ticketAssign[] = {1, 15, 20, 25, 30, 35, 40, 45, 50, 87}; //array of ticket counts
  
  int arrival_time[numProcesses];	//array for process arrival times
  int turnaround_time[numProcesses];	//array for process TA times
  
  // 2 pipes : 
  int start_pipe[2];			//tracking process starts 		
  int finish_pipe[2];			//tracking process finishes
  int finish_line[numProcesses];	//track the order of process race 
  
 
  // declare the pipes whilst checking a fail
  if(pipe(start_pipe) == -1 || pipe(finish_pipe) == -1) { 
      printf("Pipe failed\n");
      exit(1);
  }
  
  //set up the race 
  for(int i=0 ; i < numProcesses ; i++) {
      int pid = fork();		// fork the processes 
      if(pid<0) {exit(1);}	
      else if(pid == 0) {   	// child process
          
          //close reading end for child processes
          close(start_pipe[0]);
          close(finish_pipe[0]);
          
          // set the tickets using the syscall 
          settickets(ticketAssign[i]);
          
          // if the set ticket is over 100 error
          if(gettickets() >= 100) {
              printf("Error: Process %d tickets: %d, not less than 100.\n", i, gettickets());
              exit(1);
          }
          
          // write process index to the start pipe
          write(start_pipe[1], &i, sizeof(i));
          
          //wait for parent signal to start the race to finish busyWork 
          int signal;
          read(start_pipe[1], &signal, sizeof(signal));
          
          arrival_time[i] = uptime(); //uptime() syscall to store proc arrival time
          
          busyWork(); //long process to test the scheduler performance
          
          int this_turnaround = uptime() - arrival_time[i]; //store for turnaround
          
          int send_turnaround[2] = {i, this_turnaround}; //store pid and turnaround
          
          //cross the finish line and send pid / turnaround
          write(finish_pipe[1], &send_turnaround, sizeof(send_turnaround));

          exit(0);
      } 
  }
  
  // now close the writing end for parents
  close(start_pipe[1]);
  close(finish_pipe[1]);
  
  // read the start pipe, print out message
  for(int i = 0 ; i < numProcesses ; i++) {
     int started; 
     read(start_pipe[0], &started, sizeof(started));
     printf("Process %d started (ticket count %d)\n", started, ticketAssign[started]);
  }
  
  // signal each child to start work
  for(int i = 0 ; i < numProcesses ; i++) {
      int signal = 1;
      write(start_pipe[1], &signal, sizeof(signal)); //sync signal to start pipe
  }
  
  // read the finish pipe, store in finish line results
  int data_received[2];
  for(int i = 0 ; i < numProcesses ; i++) {
     read(finish_pipe[0], &data_received, sizeof(data_received));
     finish_line[i] = data_received[0];
     turnaround_time[finish_line[i]] = data_received[1];
  }
  
  // wait for all the child processes to complete
  int addr;
  for(int i = 0 ; i < numProcesses ; i++) {
      wait(&addr);
  }
  
  // print in finishing order the processes that finish
  for(int i = 0 ; i < numProcesses ; i++) {
      printf("Process %d finished\n", finish_line[i]);
  } 
  
  //display process turnaround time
  for(int i = 0 ; i < numProcesses ; i++){
      printf("Process %d Turnaround time: %d\n", i, turnaround_time[i]);
  }
  
  exit(0);
}
