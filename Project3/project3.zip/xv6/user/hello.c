#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main() { 
    printf("Hello world, this is Dylan Cozloff!\n");
    printf("I am in section 1002. \n\n");

    exit(0);
}