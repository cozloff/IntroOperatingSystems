#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main() { 
    printf("Hello world (from dylan). \n\n");
    
    printf("Current process page table 1: \n");    
    
    vmprint();
    
    exit(0);
}
